These examples are adapted from:
* http://bl.ocks.org/mbostock/4063570
* http://bl.ocks.org/mbostock/4055892
* http://bl.ocks.org/mbostock/4063550
