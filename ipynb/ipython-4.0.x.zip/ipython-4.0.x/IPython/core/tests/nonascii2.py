# coding: iso-8859-5
# (Unlikely to be the default encoding for most testers.)
# БЖџрстуфхцчшщъыьэюя <- Cyrillic characters
'Ўт№Ф'
