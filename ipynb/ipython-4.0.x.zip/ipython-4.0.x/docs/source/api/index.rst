.. _api-index:

###################
  The IPython API
###################

.. htmlonly::

   :Release: |version|
   :Date: |today|

.. include:: generated/gen.txt
